
/*
 * Auto generated Run-Time-Environment Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'blinky' 
 * Target:  'MDR32F9Q2I' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H


/*
 * Define the Device Header File: 
 */
#define CMSIS_device_header "MDR32F9Q2I.h"

/* Milandr::Device:Startup:2.1.0i */
/* Target microcontroller definition */
#define USE_MDR32F9Q2I


#endif /* RTE_COMPONENTS_H */
