#include "leds.h"
#include "main.h"

/* LED configuration structure */
typedef struct {
    MDR_PORT_TypeDef* port;
    uint32_t pin;
    uint8_t state;
} LED_ConfigTypeDef;

/* LED configuration array */
static LED_ConfigTypeDef LED_Config[LED_COUNT] = {
    {LED1_PORT, LED1_PIN, 0},
    {LED2_PORT, LED2_PIN, 0},
    {LED3_PORT, LED3_PIN, 0},
    {LED4_PORT, LED4_PIN, 0}
};

void LED_Init(void)
{
    PORT_InitTypeDef Port_InitStructure;
    
    /* Enable clocks for PORTA and PORTC */
    RST_CLK_PCLKcmd(RST_CLK_PCLK_PORTA, ENABLE);
    RST_CLK_PCLKcmd(RST_CLK_PCLK_PORTC, ENABLE);
    
    /* Common configuration for all LED pins */
    Port_InitStructure.PORT_OE = PORT_OE_OUT;
    Port_InitStructure.PORT_FUNC = PORT_FUNC_PORT;
    Port_InitStructure.PORT_MODE = PORT_MODE_ANALOG;
    Port_InitStructure.PORT_SPEED = PORT_SPEED_FAST;
    
    /* Configure each LED pin */
    for (int i = 0; i < LED_COUNT; i++) {
        Port_InitStructure.PORT_Pin = LED_Config[i].pin;
        PORT_Init(LED_Config[i].port, &Port_InitStructure);
    }
    
    /* Turn off all LEDs initially */
    LED_AllOff();
}

/**
  * @brief  Turns on specified LED
  * @param  led: LED to turn on (LED1, LED2, LED3, LED4)
  * @retval None
  */
void LED_On(LED_TypeDef led)
{
    if (led < LED_COUNT) {
        PORT_SetBits(LED_Config[led].port, LED_Config[led].pin);
        LED_Config[led].state = 1;
    }
}

/**
  * @brief  Turns off specified LED
  * @param  led: LED to turn off (LED1, LED2, LED3, LED4)
  * @retval None
  */
void LED_Off(LED_TypeDef led)
{
    if (led < LED_COUNT) {
        PORT_ResetBits(LED_Config[led].port, LED_Config[led].pin);
        LED_Config[led].state = 0;
    }
}

/**
  * @brief  Toggles specified LED
  * @param  led: LED to toggle (LED1, LED2, LED3, LED4)
  * @retval None
  */
void LED_Toggle(LED_TypeDef led)
{
    if (led < LED_COUNT) {
        if (LED_Config[led].state) {
            LED_Off(led);
        } else {
            LED_On(led);
        }
    }
}

/**
  * @brief  Sets LED state (on/off)
  * @param  led: LED to set
  * @param  state: 0 = off, any other value = on
  * @retval None
  */
void LED_SetState(LED_TypeDef led, uint8_t state)
{
    if (state) {
        LED_On(led);
    } else {
        LED_Off(led);
    }
}

/**
  * @brief  Gets current LED state
  * @param  led: LED to check
  * @retval 1 if LED is on, 0 if off or invalid LED
  */
uint8_t LED_GetState(LED_TypeDef led)
{
    if (led < LED_COUNT) {
        return LED_Config[led].state;
    }
    return 0;
}

/**
  * @brief  Runs LED sequence (running light)
  * @param  delay_ms: delay between LEDs in milliseconds
  * @retval None
  */
void LED_Sequence(uint32_t delay_time)
{
    for (int i = 0; i < LED_COUNT; i++) {
        LED_On((LED_TypeDef)i);
        HD_Delay_ms_blocking(delay_time);  // ���������� ����� delay
        LED_Off((LED_TypeDef)i);
    }
}

/**
  * @brief  Turns on all LEDs
  * @param  None
  * @retval None
  */
void LED_AllOn(void)
{
    for (int i = 0; i < LED_COUNT; i++) {
        LED_On((LED_TypeDef)i);
    }
}

/**
  * @brief  Turns off all LEDs
  * @param  None
  * @retval None
  */
void LED_AllOff(void)
{
    for (int i = 0; i < LED_COUNT; i++) {
        LED_Off((LED_TypeDef)i);
    }
}