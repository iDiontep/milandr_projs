/* USER CODE BEGIN Header */

/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/


/* USER CODE BEGIN Includes */
#include "main.h"
#include "leds.h"

/* USER CODE END Includes */

int main(void)
{
		/* Initialize LEDs */
    LED_Init();
	
	while(1)
	{
			/* Run LED sequence with 100ms delay */
			LED_Sequence(100);
	}
}
