/* USER CODE BEGIN Header */

/* USER CODE END Header */

#ifndef __MAIN_H
#define __MAIN_H

/* Includes ------------------------------------------------------------------*/

#include "MDR32FxQI_config.h"           // Milandr::Device:Startup
#include "MDR32FxQI_port.h"             // Milandr::Drivers:PORT
#include "MDR32FxQI_rst_clk.h"          // Milandr::Drivers:RST_CLK
#include "MDR32FxQI_timer.h"            // Milandr::Drivers:TIMER





#endif /* __MAIN_H */
